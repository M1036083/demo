﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Web;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.Threading;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace MicrosoftTranslatorSdk.HttpSamples
{

    public class Program
    {
        /// The client information used to get the OAuth Access Token from the server.
    
        static string clientid = "ecc97145-098a-42a1-9a5b-71069e620f0d";
        static string username = "M1036004@mindtree.com";
        static string password = "Apple@123";

        static string ResourceUrl = "https://graph.windows.net";


     
        // this will hold the Access Token returned from the server.
        static string accessToken = null;

        static void Main(string[] args)
        {
            Console.WriteLine("Starting ...");
            DoIt().Wait();
            Console.ReadLine();
        }


        /// <summary>
        /// This method does all the work to get an Access Token 
        /// </summary>
        /// <returns></returns>
        private static async Task<int> DoIt()
        {
            // Get the Access Token.

            accessToken = await GetAccessToken();
            Console.WriteLine(accessToken != null ? "Got Token" : "No Token found");
            Console.WriteLine(accessToken);

            return 0;
        }

        /// <summary>
        /// This method uses the OAuth Client Credentials Flow to get an Access Token to provide
        /// Authorization to the APIs.
        /// </summary>
        /// <returns></returns>//
        private static async Task<string> GetAccessToken()
        {


            var authority = "https://login.windows.net/common";

            var credentials = new UserPasswordCredential(username, password);
            AuthenticationContext authenticationContext = new AuthenticationContext(authority, false);
            AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(ResourceUrl, clientid, credentials);
            string token = authenticationResult.AccessToken;
            return token;
        }
    }
}
